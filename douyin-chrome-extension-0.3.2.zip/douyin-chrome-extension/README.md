# 短视频数据助手 Chrome 插件

这是一个 Manifest V3 插件。浏览器采集功能可独立运行；可选的登录同步功能需要本仓库的 FastAPI 服务及数据库。
插件使用当前 Chrome 配置文件中的平台登录状态。抖音和小红书请求都在当前平台标签页的
MAIN world 中发起，直接携带浏览器 Cookie；小红书的 MNS/X-S-Common 签名在扩展本地生成，
采集功能在浏览器内使用 Cookie；另提供可选的手动同步登录功能，将所选平台的抖音或小红书 Cookie 上传到固定服务端 `https://crawler.xoyo.com/`。

## 功能

- 通过当前 Cookie Store 和页面账号状态检测登录，兼容缺少 `s_v_web_id` 的会话。
- 根据当前活动标签页自动识别搜索页、用户主页和作品页。
- 搜索综合作品，支持数量、排序、发布时间、时长、范围和内容类型参数。
- 按总数量自动分页读取用户作品，接口持续拒绝时回退到主页滚动读取。
- 按总数量自动分页获取视频评论，可选择是否包含二级回复。
- 预览结果并导出 JSON 或 CSV。
- 小红书笔记搜索、笔记详情、用户笔记和一级评论（可包含回复）。
- 小红书请求复用当前页面签名器，并提供本地 MNS/X-S-Common 生成回退。
- 用户输入参数保存在扩展本地存储中，Cookie 不会写入扩展存储。
- 手动将当前浏览器配置的抖音或小红书登录同步到服务端对应账号池，验证后保存；支持更新已有账号。

## 安装

1. 在 Chrome 地址栏打开 `chrome://extensions/`。
2. 开启右上角的“开发者模式”。
3. 点击“加载已解压的扩展程序”。
4. 选择本目录 `douyin-chrome-extension`。
5. 打开任意 `https://www.douyin.com/` 或 `https://www.xiaohongshu.com/` 页面并完成登录。
6. 点击工具栏中的“短视频数据助手”，选择平台后开始采集。

## 使用

搜索页面会自动填写路径中的关键词，用户主页会自动填写 `sec_user_id`，作品页会自动填写作品 ID。
也可以切换功能后手动粘贴链接或输入 ID；用户作品的同一输入框会自动识别完整主页链接和 `sec_user_id`，保留链接查询参数。用户作品只需要设置总数量，插件按每页 18 条自动管理
游标和分页；只要当前是已登录的平台标签页，不要求停留在目标用户主页。评论功能只需要设置
总数量和“包含回复”开关，
请求间隔、游标与每页数量由插件自动管理。遇到安全验证时应停止任务，
在平台页面完成验证后再继续。

选择“小红书”后，搜索、笔记详情、用户笔记和评论使用当前小红书标签页的 Cookie 直接请求。
笔记链接需要携带页面或搜索结果中的 `xsec_token`；用户笔记支持主页链接或 24 位用户 ID。

## 同步抖音或小红书登录

服务端在对应 `.env.dev` 或 `.env.prod` 配置随机长密钥：抖音使用 `DOUYIN_COOKIE_IMPORT_TOKEN`，小红书使用 `XHS_COOKIE_IMPORT_TOKEN`。启用对应平台服务及数据库后重启；密钥留空时关闭该平台的导入入口。
重新加载扩展，在对应平台的已登录标签页打开侧边栏，选择“抖音”或“小红书”，展开登录同步表单，填写账号别名和该平台的同步密钥，点击“同步当前登录”。首次使用会申请 `https://crawler.xoyo.com/` 的网站访问权限。

服务地址固定为 `https://crawler.xoyo.com/`，接口分别为 `/api/v1/douyin/auth/cookie/import` 和 `/api/v1/xhs/auth/cookie/import`，不提供地址输入框，也不使用历史保存的地址。
相同账号别名更新最新凭证；服务端验证失败不会覆盖旧凭证。仅账号别名保存在本地，Cookie 与密钥不写入扩展存储，不自动监听上传。
Cookie 从当前标签页的 Cookie Store 读取，不会回退到其他配置；抖音和小红书的账号别名分别保存，切换平台清空密钥。抖音缺少 `s_v_web_id` 时复用页面或采集客户端的备用指纹；登录会话仍必须真实存在，并由服务端验证。

接口、部署和验证限制见 [浏览器 Cookie 同步说明](../docs/浏览器Cookie同步.md)。

## 隐私政策与商店提交

隐私政策正文见 [privacy-policy.html](privacy-policy.html)，依据 `manifest.json` 及当前扩展实现编写。
政策涵盖登录 Cookie、浏览器环境、查询条件、作品/评论结果、抖音和字节跳动接口传输、
本地保存与删除方式，以及 Chrome 应用商店的有限使用声明。

在 Chrome 应用商店开发者信息中心选择该扩展，在“隐私权”标签页的“隐私权政策”指定字段
填写公开网页 URL，然后保存并重新提交审核。不要把链接只放在产品说明里；本地 HTML 文件
和 `chrome-extension://` 地址不能代替公开 URL。商店的数据使用披露应与政策和实现保持一致。

## 权限用途

| 权限 | 用途 |
| --- | --- |
| `cookies` | 检测当前平台登录 Cookie |
| `declarativeNetRequestWithHostAccess` | 为 mssdk 换取 token 的请求临时设置会话请求头 |
| `activeTab` | 识别用户当前操作的标签页 |
| `scripting` | 在当前平台页面中使用登录状态发起同源请求 |
| `sidePanel` | 提供不会因弹窗关闭而中断的操作界面 |
| `storage` | 保存用户填写的非敏感参数 |
| `webNavigation` | 识别目标平台单页应用内部的 URL 切换 |
| `https://*.douyin.com/*` | 仅允许操作目标平台域名 |
| `https://xiaohongshu.com/*`、`https://*.xiaohongshu.com/*` | 在已登录的小红书页面中发起同源请求 |
| `https://mssdk.bytedance.com/*` | 换取用户作品查询使用的动态 `msToken` |
| `https://crawler.xoyo.com/*`（可选） | 仅在手动同步时申请固定服务站点权限，上传所选平台的 Cookie |

## 实现说明

- 评论列表使用从 `utils/ab_pure.py` 移植的纯 JavaScript `a_bogus` 签名。
- 综合搜索使用项目内 `js/bdms_1.0.1.19_fix.js` 的完整 BDMS 签名。
- 评论回复沿用项目规则，使用 BDMS 签名末尾 87 个字符。
- 开启“包含回复”后，一级评论与回复合计不会超过设置的数量。
- 搜索和用户作品结果会展示并导出点赞、评论、转发和收藏数量。
- 搜索、一级评论和评论回复遇到临时拒绝或无效响应时会重新签名并有限重试。
- 用户作品优先调用作品列表接口，随机 403 时重新签名并有限重试。
- 用户作品查询 token 通过 mssdk 动态生成，并按当前浏览器 `ttwid` 和指纹上报数据换取。
- 小红书请求由浏览器标签页携带 Cookie，本地生成 MNS/X-S-Common；页面已加载的签名器可补充 RAP 等动态请求头。
- 动态 `msToken` 缓存 10 分钟；连续两次 403 后强制刷新一次，最多尝试 5 次。
- 用户作品在 Service Worker 中直接请求，避免页面安全 SDK 追加或重排查询参数。
- 用户作品参数顺序与后端 API 一致，请求 Cookie 会移除旧的 `msToken`。
- 用户作品使用与 `utils/user_read` 对齐的主站 `a_bogus` 和 webSign 双签名，携带 `uifid`、`timestamp`、`x-secsdk-web-signature`，指纹参数在生成 `a_bogus` 后追加。
- 用户作品直接读取列表，不额外请求用户资料。Service Worker 原样发送签名 URL，并串行管理临时请求头规则；规则只作用于扩展自身请求。
- 接口持续被拒绝且当前正好是目标用户主页时，自动滚动读取主页作品，不请求用户信息接口。
- 浏览器 UA、屏幕尺寸、硬件并发数等参数从当前平台标签页读取，避免使用后端固定指纹。
- Cookie 查询覆盖当前页面 URL、主域名和子域名；诊断信息只展示 Cookie 名称，不展示值。
- API 原始结果仅保存在侧边栏内存中；关闭侧边栏或刷新扩展后结果会消失。

## 本地测试

在仓库根目录执行：

```powershell
node douyin-chrome-extension/tests/extension-tests.mjs
node douyin-chrome-extension/tests/xhs-extension-tests.mjs
node douyin-chrome-extension/tests/service-worker-tests.mjs
node douyin-chrome-extension/tests/cookie-sync-tests.mjs
node --check douyin-chrome-extension/lib/mstoken.js
node --check douyin-chrome-extension/sidepanel.js
node --check douyin-chrome-extension/service-worker.js
```

测试包含 URL 路由、Cookie 判定、SM3 标准向量、Python/JavaScript 固定签名向量以及四类请求构造。

## 注意事项

目标平台 Web 接口和安全规则可能调整。插件不会绕过验证码、账号权限或平台限制，也不提供代理轮换、
批量账号或自动规避风控能力。请仅处理自己有权访问和使用的数据，并控制请求频率。

隐私政策公开网址：https://dannydu26-video-helper-privacy.dannyduo26.chatgpt.site
